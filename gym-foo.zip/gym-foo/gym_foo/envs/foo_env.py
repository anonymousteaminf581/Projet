import gym
from gym import error, spaces, utils
from gym.utils import seeding
import numpy


class Player:
    def __init__(self, name):
        self.name = name
        self.balance = 0

    def decision(self, verbose = True):
        if verbose:
            print(self.name + "'s turn ! Put 1 if you want to share. Otherwise put 0.")
        return bool(input())


class FooEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, cr = 4, pr = 10, np = 2, ng = 20):
        self.collective_reward = cr
        self.personal_reward = pr
        self.num_of_players = np
        self.player = [Player(f'p{i+1}') for i in range(np)]
        self.num_of_games = ng

        self.historical = numpy.zeros((ng,np), dtype = 'int')
        self.iteration = 0
        self.unit_common_reward = [cr for i in range(np)]

    def step(self, actions):
        self.historical[self.iteration,:] = actions
        self.iteration += 1
        observation = self.historical[:self.iteration,:]
        
        nb_collective_rewards = self.num_of_players - numpy.sum(actions)
        rewards = numpy.add(numpy.multiply(nb_collective_rewards,self.unit_common_reward), numpy.multiply(self.personal_reward,actions))
        
        if self.iteration >= self.num_of_games:
            done = True
        else:
            done = False
            
        info = ""
        
        return observation, rewards, done, info

    def reset(self):
        self.historical = numpy.zeros((self.num_of_games, self.num_of_players), dtype = "int")
        self.iteration = 0
        
        return [player.balance for player in self.player]
    
    def render(self, mode='human'):
        print(f"Last actions : {self.historical[self.iteration,:]}")
        scores = [player.balance for player in self.player]
        print(f"scores : {scores}")

    def close(self):
        for line in self.historical:
            print(''.join(map(str,line)))
        scores = [player.balance for player in self.player]
        print(f"scores : {scores}")
        leader = numpy.argmax(scores)
        print(f"{self.player[leader].name} has won !")

